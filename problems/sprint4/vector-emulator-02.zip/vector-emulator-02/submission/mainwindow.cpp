#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) {
    ui->setupUi(this);

    ApplyModel();
    ApplyIterator();
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::ApplyIterator(){
    if(vector_model_.items.end() == vector_model_.iterator){
        ui->pb_plus->setEnabled(false);
        ui->pb_edit->setEnabled(false);
        ui->pb_erase->setEnabled(false);
        ui->txt_elem_content->clear();
    }else{
        ui->pb_plus->setEnabled(true);
        ui->pb_edit->setEnabled(true);
        ui->pb_erase->setEnabled(true);
    }
    if(vector_model_.items.empty()){
        ui->btn_dec->setEnabled(false);
        ui->pb_plus->setEnabled(false);
    }
    if(vector_model_.items.end() != vector_model_.iterator && vector_model_.items.size() > 0){
        ui->pb_plus->setEnabled(true);
    }
    if(vector_model_.items.begin() == vector_model_.iterator){
        ui->btn_dec->setEnabled(false);
    }else{
        ui->btn_dec->setEnabled(true);
    }
    int index = std::distance(vector_model_.items.begin(), vector_model_.iterator);
    if(vector_model_.items.size() > 0){
        ui->txt_elem_content->setText(QString::fromStdString(*vector_model_.iterator));
    }
    ui->list_widget->setCurrentRow(index);
}

void MainWindow::ApplyModel() {
    ui->list_widget->clear();


    if(vector_model_.items.empty()){
        ui->pb_pop_back->setEnabled(false);
    }else{
        ui->pb_pop_back->setEnabled(true);
    }
    ui->txt_size->setText(QString::number(vector_model_.items.size()));
    QStringList res;
    res.clear();
    for(const auto& item : vector_model_.items){
        res.push_back(QString::fromStdString(item));
    }

    for(int i = 0; i < res.size(); i++){
        ui->list_widget->addItem(QString::number(i) + ": " + res[i]);
    }
    ui->list_widget->addItem("end");

}


void MainWindow::on_pb_days_of_week_clicked()
{
    static std::vector<std::string> days_of_week = {
        "Понедельник",
        "Вторник",
        "Среда",
        "Четверг",
        "Пятница",
        "Суббота",
        "Воскресенье"
    };

    vector_model_.items = days_of_week;
    vector_model_.iterator = vector_model_.items.begin();
    ApplyModel();
    ApplyIterator();
}


void MainWindow::on_pb_months_clicked()
{
    static std::vector<std::string> months_of_year = {
        "Январь",
        "Февраль",
        "Март",
        "Апрель",
        "Май",
        "Июнь",
        "Июль",
        "Август",
        "Сентябрь",
        "Октябрь",
        "Ноябрь",
        "Декабрь"
    };

    vector_model_.items = months_of_year;
    vector_model_.iterator = vector_model_.items.begin();
    ApplyModel();
    ApplyIterator();
}


void MainWindow::on_pb_pop_back_clicked()
{
    vector_model_.items.pop_back();
    vector_model_.iterator = vector_model_.items.begin();
    ApplyModel();
    ApplyIterator();
}


void MainWindow::on_pb_clear_clicked()
{
    vector_model_.items.clear();
    vector_model_.iterator = vector_model_.items.begin();
    ApplyModel();
    ApplyIterator();
}


void MainWindow::on_pb_push_back_2_clicked()
{
    std::string item = ui->txt_elem_content->text().toStdString();
    if(item.empty()){
        return;
    }
    vector_model_.items.push_back(item);
    vector_model_.iterator = vector_model_.items.begin();
    ApplyModel();
    ApplyIterator();
}

void MainWindow::on_pb_plus_clicked()
{
    ++vector_model_.iterator;
    ApplyIterator();
}


void MainWindow::on_pb_begin_clicked()
{
    vector_model_.iterator = vector_model_.items.begin();
    ApplyIterator();
}


void MainWindow::on_pb_end_clicked()
{
    vector_model_.iterator = vector_model_.items.end();
    ApplyIterator();
}


void MainWindow::on_pb_edit_clicked()
{
    auto iter = vector_model_.iterator;
    *vector_model_.iterator = ui->txt_elem_content->text().toStdString();
    vector_model_.iterator = vector_model_.items.begin();
    ApplyModel();
    vector_model_.iterator = iter;
    ApplyIterator();
}


void MainWindow::on_pb_erase_clicked()
{
    vector_model_.items.erase(vector_model_.iterator);
    vector_model_.iterator = vector_model_.items.begin();
    ApplyModel();
    ApplyIterator();
}


void MainWindow::on_pb_insert_clicked()
{
    vector_model_.items.insert(vector_model_.iterator, ui->txt_elem_content->text().toStdString());
    vector_model_.iterator = vector_model_.items.begin();
    ApplyModel();
    ApplyIterator();
}


void MainWindow::on_btn_dec_clicked()
{
    --vector_model_.iterator;
    ApplyIterator();
}

