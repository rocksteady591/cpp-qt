#pragma once
#include <QString>

void OpenCustomUrl(const QString& url);
void OpenCustomDirectory(const QString& path);

void OpenYandex();
void OpenPracticum();
void OpenHomeDirectory();
void OpenCmd();
void OpenUrl();
void OpenFolder();
