#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

}

MainWindow::~MainWindow() {
    delete ui;
}


void MainWindow::on_pb_one_clicked()
{

}


void MainWindow::on_pb_two_clicked()
{

}


void MainWindow::on_pb_three_clicked()
{

}


void MainWindow::on_pb_four_clicked()
{

}


void MainWindow::on_pb_five_clicked()
{

}


void MainWindow::on_pb_six_clicked()
{

}


void MainWindow::on_pb_seven_clicked()
{

}


void MainWindow::on_pb_eight_clicked()
{

}


void MainWindow::on_pb_nine_clicked()
{

}


void MainWindow::on_pb_zero_clicked()
{

}


void MainWindow::on_tb_extra_clicked()
{

}


void MainWindow::on_pb_delete_clicked()
{

}


void MainWindow::on_pb_result_clicked()
{

}


void MainWindow::on_pb_add_clicked()
{

}


void MainWindow::on_pb_substraction_clicked()
{

}


void MainWindow::on_pb_multiply_clicked()
{

}


void MainWindow::on_pb_division_clicked()
{

}


void MainWindow::on_pb_change_of_sign_clicked()
{

}


void MainWindow::on_pb_clear_clicked()
{

}


void MainWindow::on_pb_pow_clicked()
{

}


void MainWindow::on_pb_save_number_clicked()
{

}


void MainWindow::on_pb_memory_read_clicked()
{

}


void MainWindow::on_pb_memory_clear_clicked()
{

}

